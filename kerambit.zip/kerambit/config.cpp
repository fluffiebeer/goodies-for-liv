class CfgPatches
{
	class Fluffie_Customs_Kerambit
	{
		units[]={};
		weapons[]={};
		requiredVersion=0.1;
		requiredAddons[]=
		{
			"DZ_Data",
			"DZ_Weapons_Melee"
		};
	};
};
class CfgMods
{
	class FC_Kerambit
	{	
		
		dir = "Fluffie_Customs_Main";
		picture = "";
		action = "";
		hideName = 1;
		hidePicture = 1;
		name = "";
		type = "mod";
	};
};

class CfgVehicles
{
	class CombatKnife;
	class FC_Kerambit_Base: CombatKnife
	{
		scope=0; //always have base items be scope 0
		model="Fluffie_Customs_Main\kerambit\kb.p3d";
		SingleUseActions[]={533};
		ContinuousActions[]={168,193};
		build_action_type=10;
		dismantle_action_type=0;
		rotationFlags=17;
		weight=940;
		itemSize[]={2,3};
		fragility=0.0080000004;
		openItemSpillRange[]={20,50};
	};
    class FC_Kerambit_Normal: FC_Kerambit_Base
    {
        scope = 2;
		displayName="Kerambit Knife";
		descriptionShort="CSGO Style knife, Kerambit.";
		hiddenSelections[]=
        {
		  "knife"
        };
        hiddenSelectionsTextures[] =
        {
            "Fluffie_Customs_Main\kerambit\textures\Spiderman_Knife.paa"			
		};
    };
};